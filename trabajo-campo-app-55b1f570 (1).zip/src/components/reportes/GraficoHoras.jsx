import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { groupBy } from 'lodash';

export default function GraficoHoras({ registros }) {
  const registrosPorEmpleado = groupBy(registros, 'empleado_nombre');
  
  const data = Object.entries(registrosPorEmpleado).map(([nombre, regs]) => ({
    empleado: nombre,
    horas: regs.reduce((sum, r) => sum + (r.horas_trabajadas || 0), 0)
  })).sort((a, b) => b.horas - a.horas).slice(0, 10);

  return (
    <Card className="shadow-lg border-0">
      <CardHeader className="bg-gradient-to-r from-blue-900 to-blue-800 text-white rounded-t-xl">
        <CardTitle>Horas por Empleado</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis type="number" stroke="#64748b" />
            <YAxis dataKey="empleado" type="category" stroke="#64748b" width={120} />
            <Tooltip
              contentStyle={{
                backgroundColor: 'white',
                border: '1px solid #e2e8f0',
                borderRadius: '8px'
              }}
            />
            <Bar dataKey="horas" fill="#14b8a6" radius={[0, 8, 8, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}