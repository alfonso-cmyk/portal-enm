import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { format, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from "date-fns";

export default function FiltroReportes({ tipoReporte, setTipoReporte, fechaInicio, setFechaInicio, fechaFin, setFechaFin }) {
  const aplicarPeriodo = (tipo) => {
    setTipoReporte(tipo);
    const hoy = new Date();
    
    switch(tipo) {
      case 'semanal':
        setFechaInicio(format(startOfWeek(hoy, { weekStartsOn: 1 }), "yyyy-MM-dd"));
        setFechaFin(format(endOfWeek(hoy, { weekStartsOn: 1 }), "yyyy-MM-dd"));
        break;
      case 'mensual':
        setFechaInicio(format(startOfMonth(hoy), "yyyy-MM-dd"));
        setFechaFin(format(endOfMonth(hoy), "yyyy-MM-dd"));
        break;
    }
  };

  return (
    <Card className="shadow-lg border-0 mb-8">
      <CardContent className="p-6">
        <div className="grid md:grid-cols-4 gap-4">
          <div>
            <Label className="text-sm text-slate-600 mb-2">Período</Label>
            <Select value={tipoReporte} onValueChange={aplicarPeriodo}>
              <SelectTrigger className="rounded-lg">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="semanal">Esta Semana</SelectItem>
                <SelectItem value="mensual">Este Mes</SelectItem>
                <SelectItem value="personalizado">Personalizado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm text-slate-600 mb-2">Fecha Inicio</Label>
            <Input
              type="date"
              value={fechaInicio}
              onChange={(e) => setFechaInicio(e.target.value)}
              className="rounded-lg"
            />
          </div>

          <div>
            <Label className="text-sm text-slate-600 mb-2">Fecha Fin</Label>
            <Input
              type="date"
              value={fechaFin}
              onChange={(e) => setFechaFin(e.target.value)}
              className="rounded-lg"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}