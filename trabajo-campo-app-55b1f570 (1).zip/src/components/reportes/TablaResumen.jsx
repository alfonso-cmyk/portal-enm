import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { groupBy } from 'lodash';

export default function TablaResumen({ registros, empleados }) {
  const registrosPorEmpleado = groupBy(registros, 'empleado_id');
  
  const resumen = empleados.map(emp => {
    const regsEmpleado = registrosPorEmpleado[emp.id] || [];
    const horas = regsEmpleado.reduce((sum, r) => sum + (r.horas_trabajadas || 0), 0);
    
    return {
      nombre: emp.full_name,
      profesion: emp.profesion,
      registros: regsEmpleado.length,
      horas: horas.toFixed(1),
      promedio: regsEmpleado.length > 0 ? (horas / regsEmpleado.length).toFixed(1) : '0.0'
    };
  }).filter(e => e.registros > 0);

  return (
    <Card className="shadow-lg border-0">
      <CardHeader className="bg-gradient-to-r from-slate-700 to-slate-800 text-white rounded-t-xl">
        <CardTitle>Resumen Detallado por Empleado</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead>Empleado</TableHead>
                <TableHead>Profesión</TableHead>
                <TableHead className="text-center">Registros</TableHead>
                <TableHead className="text-center">Horas Totales</TableHead>
                <TableHead className="text-center">Promedio/Día</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {resumen.map((emp, index) => (
                <TableRow key={index} className="hover:bg-slate-50 transition-colors">
                  <TableCell className="font-medium">{emp.nombre}</TableCell>
                  <TableCell>{emp.profesion}</TableCell>
                  <TableCell className="text-center">{emp.registros}</TableCell>
                  <TableCell className="text-center font-semibold text-teal-600">
                    {emp.horas}h
                  </TableCell>
                  <TableCell className="text-center">{emp.promedio}h</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}