import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Camera, AlertCircle, DollarSign, Shield } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function ModalEmpleado({ empleado, centros, onClose }) {
  const [formData, setFormData] = useState({
    full_name: empleado?.full_name || '',
    email: empleado?.email || '',
    role: empleado?.role || 'user',
    profesion: empleado?.profesion || '',
    centros_asignados: empleado?.centros_asignados || [],
    horas_semanales: empleado?.horas_semanales || 40,
    telefono: empleado?.telefono || '',
    fecha_nacimiento: empleado?.fecha_nacimiento || '',
    foto_perfil: empleado?.foto_perfil || '',
    activo: empleado?.activo !== false,
    puede_subir_gastos: empleado?.puede_subir_gastos || false
  });
  const [uploadingFoto, setUploadingFoto] = useState(false);

  const updateMutation = useMutation({
    mutationFn: async (data) => {
      console.log('🔄 Actualizando empleado:', empleado.id, data);
      const result = await base44.entities.User.update(empleado.id, data);
      console.log('✅ Actualización guardada:', result);
      return result;
    },
    onSuccess: () => {
      console.log('✅ Recargando página...');
      window.location.reload();
    },
    onError: (error) => {
      console.error('❌ Error al actualizar empleado:', error);
      alert('❌ Error al actualizar el empleado: ' + (error.message || 'Por favor, intenta de nuevo.'));
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.email.includes('@')) {
      alert('Por favor, introduce un email válido');
      return;
    }
    
    if (!formData.full_name.trim()) {
      alert('El nombre no puede estar vacío');
      return;
    }
    
    console.log('📝 Guardando cambios...');
    updateMutation.mutate(formData);
  };

  const handleSubirFoto = async (e) => {
    const file = e.target.files[0];
    if (file) {
      setUploadingFoto(true);
      try {
        const result = await base44.integrations.Core.UploadFile({ file });
        setFormData({...formData, foto_perfil: result.file_url});
      } catch (error) {
        alert('Error al subir la foto');
      } finally {
        setUploadingFoto(false);
      }
    }
  };

  const toggleCentro = (centroId) => {
    const nuevos = formData.centros_asignados.includes(centroId)
      ? formData.centros_asignados.filter(id => id !== centroId)
      : [...formData.centros_asignados, centroId];
    setFormData({...formData, centros_asignados: nuevos});
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editar Empleado</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4">
            <Alert className="border-green-200 bg-green-50">
              <AlertCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-900 text-sm">
                <strong>Administrador:</strong> Puedes editar todos los datos del empleado, incluyendo nombre, email y rol.
              </AlertDescription>
            </Alert>

            <div className="flex flex-col items-center">
              <Label className="mb-2">Foto de Perfil</Label>
              <div className="relative">
                <Avatar className="w-24 h-24 bg-gradient-to-br from-[#24c4ba] to-[#1ca89f]">
                  {formData.foto_perfil ? (
                    <AvatarImage src={formData.foto_perfil} />
                  ) : null}
                  <AvatarFallback className="bg-transparent text-white text-3xl font-bold">
                    {formData.full_name?.charAt(0)?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleSubirFoto}
                  className="hidden"
                  id="foto-perfil-input"
                />
                <label
                  htmlFor="foto-perfil-input"
                  className="absolute bottom-0 right-0 bg-[#24c4ba] text-white p-2 rounded-full cursor-pointer hover:bg-[#1ca89f] transition-colors"
                >
                  <Camera className="w-4 h-4" />
                </label>
              </div>
              {uploadingFoto && <p className="text-sm text-[#24c4ba] mt-2">Subiendo foto...</p>}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="full_name">Nombre Completo *</Label>
                <Input
                  id="full_name"
                  value={formData.full_name}
                  onChange={(e) => setFormData({...formData, full_name: e.target.value})}
                  placeholder="Nombre completo del empleado"
                  className="mt-2"
                  required
                />
              </div>

              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  placeholder="email@ejemplo.com"
                  className="mt-2"
                  required
                />
              </div>
            </div>

            <div className="p-4 bg-gradient-to-r from-amber-50 to-amber-100 rounded-lg border-2 border-amber-200">
              <Label htmlFor="role" className="flex items-center gap-2 text-amber-900 font-bold mb-2">
                <Shield className="w-5 h-5" />
                Rol del Usuario
              </Label>
              <Select
                value={formData.role}
                onValueChange={(value) => setFormData({...formData, role: value})}
              >
                <SelectTrigger id="role" className="mt-2 bg-white">
                  <SelectValue placeholder="Selecciona rol" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">
                    <div>
                      <div className="font-semibold">Usuario / Trabajador</div>
                      <div className="text-xs text-slate-600">Acceso a fichaje, registro de trabajos y documentos</div>
                    </div>
                  </SelectItem>
                  <SelectItem value="admin">
                    <div>
                      <div className="font-semibold text-amber-900">Administrador</div>
                      <div className="text-xs text-amber-700">Acceso completo a gestión, reportes y configuración</div>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-amber-800 mt-2">
                ⚠️ Los administradores tienen acceso completo al sistema
              </p>
            </div>

            <div>
              <Label htmlFor="profesion-select">Profesión</Label>
              <Select
                value={formData.profesion}
                onValueChange={(value) => setFormData({...formData, profesion: value})}
              >
                <SelectTrigger id="profesion-select" className="mt-2">
                  <SelectValue placeholder="Selecciona profesión (opcional)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="limpieza">Limpieza</SelectItem>
                  <SelectItem value="jardineria">Jardinería</SelectItem>
                  <SelectItem value="piscinero">Piscinero</SelectItem>
                  <SelectItem value="socorrista">Socorrista</SelectItem>
                  <SelectItem value="mantenimiento">Mantenimiento</SelectItem>
                  <SelectItem value="otro">Otro</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="telefono">Teléfono (con prefijo: +34)</Label>
                <Input
                  id="telefono"
                  value={formData.telefono}
                  onChange={(e) => setFormData({...formData, telefono: e.target.value})}
                  placeholder="+34 600 000 000"
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="fecha_nacimiento">Fecha de Nacimiento</Label>
                <Input
                  id="fecha_nacimiento"
                  type="date"
                  value={formData.fecha_nacimiento}
                  onChange={(e) => setFormData({...formData, fecha_nacimiento: e.target.value})}
                  className="mt-2"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="horas_semanales">Horas Semanales</Label>
              <Input
                id="horas_semanales"
                type="number"
                value={formData.horas_semanales}
                onChange={(e) => setFormData({...formData, horas_semanales: parseFloat(e.target.value)})}
                className="mt-2"
              />
            </div>

            <div>
              <Label className="mb-3 block">Centros Asignados</Label>
              <div className="flex flex-wrap gap-2">
                {centros.map(centro => {
                  const isSelected = formData.centros_asignados.includes(centro.id);
                  return (
                    <button
                      key={centro.id}
                      type="button"
                      onClick={() => toggleCentro(centro.id)}
                      className={`px-4 py-2 rounded-lg border-2 transition-all duration-200 ${
                        isSelected
                          ? 'border-teal-500 bg-teal-50 text-teal-700 font-semibold'
                          : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      {centro.nombre}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-lg">
              <input
                type="checkbox"
                id="activo"
                checked={formData.activo}
                onChange={(e) => setFormData({...formData, activo: e.target.checked})}
                className="w-5 h-5 rounded border-slate-300"
              />
              <Label htmlFor="activo" className="cursor-pointer">
                Empleado Activo
                <p className="text-xs text-slate-600 font-normal mt-1">
                  Los empleados inactivos no podrán registrar trabajos
                </p>
              </Label>
            </div>

            <div className="flex items-center gap-3 p-4 bg-orange-50 rounded-lg border-2 border-orange-200">
              <input
                type="checkbox"
                id="puede_subir_gastos"
                checked={formData.puede_subir_gastos}
                onChange={(e) => setFormData({...formData, puede_subir_gastos: e.target.checked})}
                className="w-5 h-5 rounded border-orange-300"
              />
              <Label htmlFor="puede_subir_gastos" className="cursor-pointer">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-orange-600" />
                  <span className="font-semibold text-orange-900">Puede subir gastos</span>
                </div>
                <p className="text-xs text-orange-700 font-normal mt-1">
                  Permitir a este empleado registrar gastos para reembolso
                </p>
              </Label>
            </div>
          </div>

          <DialogFooter className="mt-6">
            <Button type="button" variant="outline" onClick={onClose} disabled={updateMutation.isPending}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={updateMutation.isPending}
              className="bg-gradient-to-r from-[#24c4ba] to-[#1ca89f]"
            >
              {updateMutation.isPending ? 'Guardando...' : 'Guardar Cambios'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}