import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Edit, Mail, Phone, Briefcase, Building2, AlertCircle, Power, MessageCircle, Clock } from "lucide-react";
import { motion } from "framer-motion";

const profesionColors = {
  limpieza: "bg-blue-100 text-blue-800",
  jardineria: "bg-green-100 text-green-800",
  piscinero: "bg-cyan-100 text-cyan-800",
  socorrista: "bg-red-100 text-red-800",
  mantenimiento: "bg-amber-100 text-amber-800",
  otro: "bg-slate-100 text-slate-800"
};

const roleColors = {
  admin: "bg-gradient-to-r from-[#d4af37] to-[#c9a332] text-[#1a1a1a]",
  user: "bg-gradient-to-r from-[#24c4ba] to-[#1ca89f] text-white"
};

export default function EmpleadoCard({ empleado, centros, onEditar, onToggleActivo, onVerHorario, sinConfigurar, horasSemanales }) {
  const centrosAsignados = centros.filter(c => 
    empleado.centros_asignados?.includes(c.id)
  );

  const isInactivo = empleado.activo === false;

  const enviarWhatsApp = () => {
    if (empleado.telefono) {
      const telefono = empleado.telefono.replace(/\s/g, '');
      const mensaje = encodeURIComponent(`Hola ${empleado.full_name}, `);
      window.open(`https://wa.me/${telefono}?text=${mensaje}`, '_blank');
    } else {
      alert('Este empleado no tiene teléfono registrado');
    }
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
    >
      <Card className={`shadow-lg border-0 hover:shadow-xl transition-shadow duration-200 ${
        sinConfigurar ? 'border-2 border-amber-300' : ''
      } ${isInactivo ? 'opacity-60 border-2 border-slate-300' : ''}`}>
        <CardContent className="p-6">
          {isInactivo && (
            <div className="mb-3 flex items-center gap-2 text-red-600 bg-red-50 p-2 rounded-lg">
              <Power className="w-4 h-4" />
              <span className="text-xs font-medium">Empleado Desactivado</span>
            </div>
          )}

          {sinConfigurar && !isInactivo && (
            <div className="mb-3 flex items-center gap-2 text-amber-600 bg-amber-50 p-2 rounded-lg">
              <AlertCircle className="w-4 h-4" />
              <span className="text-xs font-medium">Requiere configuración</span>
            </div>
          )}
          
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <Avatar className={`w-14 h-14 ${isInactivo ? 'bg-gradient-to-br from-slate-400 to-slate-500' : 'bg-gradient-to-br from-[#24c4ba] to-[#1ca89f]'}`}>
                {empleado.foto_perfil ? (
                  <AvatarImage src={empleado.foto_perfil} alt={empleado.full_name} />
                ) : null}
                <AvatarFallback className="bg-transparent text-white text-xl font-bold">
                  {empleado.full_name?.charAt(0)?.toUpperCase() || 'U'}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-bold text-lg text-[#1a1a1a]">
                  {empleado.full_name}
                </h3>
                <div className="flex gap-2 mt-1 flex-wrap">
                  <Badge className={roleColors[empleado.role] || roleColors.user}>
                    {empleado.role === 'admin' ? 'Administrador' : 'Trabajador'}
                  </Badge>
                  {empleado.profesion && (
                    <Badge className={profesionColors[empleado.profesion]}>
                      {empleado.profesion}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              {empleado.telefono && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={enviarWhatsApp}
                  className="text-green-600 hover:text-green-700 hover:bg-green-50"
                  title="Enviar WhatsApp"
                >
                  <MessageCircle className="w-4 h-4" />
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onEditar(empleado)}
                className="text-slate-600 hover:text-[#24c4ba]"
              >
                <Edit className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onToggleActivo(empleado)}
                className={isInactivo ? "text-green-600 hover:text-green-700" : "text-red-600 hover:text-red-700"}
                title={isInactivo ? "Activar empleado" : "Desactivar empleado"}
              >
                <Power className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Mail className="w-4 h-4" />
              <span className="truncate">{empleado.email}</span>
            </div>

            {empleado.telefono ? (
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Phone className="w-4 h-4" />
                <span>{empleado.telefono}</span>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <Phone className="w-4 h-4" />
                <span className="italic">Sin teléfono</span>
              </div>
            )}

            {horasSemanales !== undefined && horasSemanales > 0 ? (
              <div className="flex items-center gap-2 text-sm font-semibold text-[#24c4ba]">
                <Clock className="w-4 h-4" />
                <span>{horasSemanales}h semanales programadas</span>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <Briefcase className="w-4 h-4" />
                <span className="italic">Sin horario configurado</span>
              </div>
            )}

            {centrosAsignados.length > 0 ? (
              <div>
                <div className="flex items-center gap-2 text-sm text-slate-600 mb-2">
                  <Building2 className="w-4 h-4" />
                  <span className="font-medium">Centros:</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {centrosAsignados.map(centro => (
                    <Badge key={centro.id} variant="outline" className="text-xs">
                      {centro.nombre}
                    </Badge>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 p-2 rounded">
                <Building2 className="w-4 h-4" />
                <span className="font-medium">Sin centros asignados</span>
              </div>
            )}

            <Button
              variant="outline"
              className="w-full mt-4 border-[#24c4ba] text-[#24c4ba] hover:bg-[#24c4ba] hover:text-white"
              onClick={() => onVerHorario(empleado)}
            >
              <Clock className="w-4 h-4 mr-2" />
              Ver/Editar Horario
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}