import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Clock, MapPin, Copy } from "lucide-react";

const diasSemana = [
  { value: 'lunes', label: 'Lunes' },
  { value: 'martes', label: 'Martes' },
  { value: 'miercoles', label: 'Miércoles' },
  { value: 'jueves', label: 'Jueves' },
  { value: 'viernes', label: 'Viernes' },
  { value: 'sabado', label: 'Sábado' },
  { value: 'domingo', label: 'Domingo' }
];

export default function ModalHorario({ empleado, centros, onClose }) {
  const queryClient = useQueryClient();
  const [nuevoHorario, setNuevoHorario] = useState({
    dia_semana: '',
    centro_id: '',
    ubicacion: '',
    hora_inicio: '',
    hora_fin: ''
  });
  const [horarioADuplicar, setHorarioADuplicar] = useState(null);

  const { data: horarios = [] } = useQuery({
    queryKey: ['horarios-empleado', empleado.id],
    queryFn: () => base44.entities.HorarioSemanal.filter({ empleado_id: empleado.id }),
    initialData: [],
  });

  const centrosEmpleado = centros.filter(c => empleado.centros_asignados?.includes(c.id));

  const createHorarioMutation = useMutation({
    mutationFn: (data) => {
      const centro = centros.find(c => c.id === data.centro_id);
      const horaInicio = new Date(`2000-01-01T${data.hora_inicio}`);
      const horaFin = new Date(`2000-01-01T${data.hora_fin}`);
      const horasDia = (horaFin - horaInicio) / (1000 * 60 * 60);

      return base44.entities.HorarioSemanal.create({
        empleado_id: empleado.id,
        empleado_nombre: empleado.full_name,
        dia_semana: data.dia_semana,
        centro_id: data.centro_id,
        centro_nombre: centro?.nombre || '',
        ubicacion: data.ubicacion,
        hora_inicio: data.hora_inicio,
        hora_fin: data.hora_fin,
        horas_dia: horasDia,
        activo: true
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['horarios-empleado'] });
      queryClient.invalidateQueries({ queryKey: ['horarios'] });
      setNuevoHorario({
        dia_semana: '',
        centro_id: '',
        ubicacion: '',
        hora_inicio: '',
        hora_fin: ''
      });
      setHorarioADuplicar(null);
    },
  });

  const deleteHorarioMutation = useMutation({
    mutationFn: (id) => base44.entities.HorarioSemanal.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['horarios-empleado'] });
      queryClient.invalidateQueries({ queryKey: ['horarios'] });
    },
  });

  const handleAgregarHorario = (e) => {
    e.preventDefault();
    if (!nuevoHorario.dia_semana || !nuevoHorario.centro_id || !nuevoHorario.hora_inicio || !nuevoHorario.hora_fin) {
      alert('Por favor completa todos los campos obligatorios');
      return;
    }
    createHorarioMutation.mutate(nuevoHorario);
  };

  const handleDuplicarHorario = (horario) => {
    setHorarioADuplicar(horario);
    setNuevoHorario({
      dia_semana: '',
      centro_id: horario.centro_id,
      ubicacion: horario.ubicacion,
      hora_inicio: horario.hora_inicio,
      hora_fin: horario.hora_fin
    });
  };

  const handleDuplicarATodosDias = (horario) => {
    if (confirm('¿Duplicar este horario a TODOS los días de la semana?')) {
      const diasADuplicar = diasSemana.filter(d => d.value !== horario.dia_semana);
      
      diasADuplicar.forEach(dia => {
        createHorarioMutation.mutate({
          dia_semana: dia.value,
          centro_id: horario.centro_id,
          ubicacion: horario.ubicacion,
          hora_inicio: horario.hora_inicio,
          hora_fin: horario.hora_fin
        });
      });
    }
  };

  const horariosPorDia = diasSemana.map(dia => ({
    ...dia,
    horarios: horarios.filter(h => h.dia_semana === dia.value && h.activo !== false)
  }));

  const totalHorasSemanales = horarios
    .filter(h => h.activo !== false)
    .reduce((sum, h) => sum + (h.horas_dia || 0), 0);

  const centroSeleccionado = centros.find(c => c.id === nuevoHorario.centro_id);

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            Horario Semanal de {empleado.full_name}
          </DialogTitle>
        </DialogHeader>

        <div className="mb-6 p-4 bg-gradient-to-r from-[#24c4ba] to-[#1ca89f] rounded-xl text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm opacity-90">Total Horas Semanales</p>
              <p className="text-4xl font-bold">{totalHorasSemanales.toFixed(1)}h</p>
            </div>
            <Clock className="w-12 h-12 opacity-80" />
          </div>
        </div>

        {horarioADuplicar && (
          <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-900 font-semibold">Duplicando horario de {horarioADuplicar.dia_semana}</p>
                <p className="text-xs text-blue-700">{horarioADuplicar.hora_inicio} - {horarioADuplicar.hora_fin}</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setHorarioADuplicar(null);
                  setNuevoHorario({
                    dia_semana: '',
                    centro_id: '',
                    ubicacion: '',
                    hora_inicio: '',
                    hora_fin: ''
                  });
                }}
              >
                Cancelar
              </Button>
            </div>
          </div>
        )}

        <div className="mb-6">
          <h3 className="font-bold text-lg mb-4 text-[#1a1a1a]">
            {horarioADuplicar ? 'Seleccionar días para duplicar' : 'Agregar Horario'}
          </h3>
          <form onSubmit={handleAgregarHorario} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Día de la Semana *</Label>
                <Select
                  value={nuevoHorario.dia_semana}
                  onValueChange={(value) => setNuevoHorario({...nuevoHorario, dia_semana: value})}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Selecciona día" />
                  </SelectTrigger>
                  <SelectContent>
                    {diasSemana.map(dia => (
                      <SelectItem key={dia.value} value={dia.value}>{dia.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Centro *</Label>
                <Select
                  value={nuevoHorario.centro_id}
                  onValueChange={(value) => setNuevoHorario({...nuevoHorario, centro_id: value, ubicacion: ''})}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Selecciona centro" />
                  </SelectTrigger>
                  <SelectContent>
                    {centrosEmpleado.map(centro => (
                      <SelectItem key={centro.id} value={centro.id}>{centro.nombre}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {centroSeleccionado && centroSeleccionado.ubicaciones && centroSeleccionado.ubicaciones.length > 0 && (
              <div>
                <Label>Ubicación</Label>
                <Select
                  value={nuevoHorario.ubicacion}
                  onValueChange={(value) => setNuevoHorario({...nuevoHorario, ubicacion: value})}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Selecciona ubicación" />
                  </SelectTrigger>
                  <SelectContent>
                    {centroSeleccionado.ubicaciones.map((ubi, index) => (
                      <SelectItem key={index} value={ubi}>{ubi}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Hora Inicio *</Label>
                <Input
                  type="time"
                  value={nuevoHorario.hora_inicio}
                  onChange={(e) => setNuevoHorario({...nuevoHorario, hora_inicio: e.target.value})}
                  className="mt-2"
                />
              </div>
              <div>
                <Label>Hora Fin *</Label>
                <Input
                  type="time"
                  value={nuevoHorario.hora_fin}
                  onChange={(e) => setNuevoHorario({...nuevoHorario, hora_fin: e.target.value})}
                  className="mt-2"
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-[#24c4ba] to-[#1ca89f] text-white"
              disabled={createHorarioMutation.isPending}
            >
              <Plus className="w-4 h-4 mr-2" />
              {horarioADuplicar ? 'Duplicar Horario' : 'Agregar Horario'}
            </Button>
          </form>
        </div>

        <div>
          <h3 className="font-bold text-lg mb-4 text-[#1a1a1a]">Horario Semanal Actual</h3>
          <div className="space-y-3">
            {horariosPorDia.map(dia => (
              <div key={dia.value}>
                <h4 className="font-semibold text-[#1a1a1a] mb-2 flex items-center gap-2">
                  {dia.label}
                  {dia.horarios.length > 0 && (
                    <Badge className="bg-[#24c4ba] text-white">
                      {dia.horarios.reduce((sum, h) => sum + (h.horas_dia || 0), 0).toFixed(1)}h
                    </Badge>
                  )}
                </h4>
                {dia.horarios.length === 0 ? (
                  <p className="text-sm text-slate-500 italic ml-4">Sin horario</p>
                ) : (
                  <div className="space-y-2 ml-4">
                    {dia.horarios.map((horario) => (
                      <Card key={horario.id} className="border-l-4 border-[#24c4ba]">
                        <CardContent className="p-3 flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <MapPin className="w-4 h-4 text-[#24c4ba]" />
                              <span className="font-medium">{horario.centro_nombre}</span>
                              {horario.ubicacion && (
                                <Badge variant="outline" className="text-xs">{horario.ubicacion}</Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-sm text-slate-600">
                              <Clock className="w-4 h-4" />
                              <span>{horario.hora_inicio} - {horario.hora_fin}</span>
                              <Badge className="bg-[#d4af37] text-[#1a1a1a]">
                                {horario.horas_dia}h
                              </Badge>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDuplicarHorario(horario)}
                              className="text-blue-600 hover:text-blue-700"
                              title="Duplicar a otro día"
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDuplicarATodosDias(horario)}
                              className="text-green-600 hover:text-green-700"
                              title="Duplicar a todos los días"
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                if (confirm('¿Eliminar este horario?')) {
                                  deleteHorarioMutation.mutate(horario.id);
                                }
                              }}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}