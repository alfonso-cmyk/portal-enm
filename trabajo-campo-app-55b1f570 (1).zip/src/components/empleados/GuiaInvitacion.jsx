import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { UserPlus, CheckCircle, Mail, Key } from "lucide-react";

export default function GuiaInvitacion({ onClose }) {
  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-3">
            <UserPlus className="w-7 h-7 text-blue-900" />
            Guía: Cómo Invitar Empleados
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg">
            <h3 className="font-bold text-blue-900 mb-2">Información Importante</h3>
            <p className="text-blue-800">
              Los usuarios deben ser invitados desde el <strong>Dashboard principal</strong> por razones de seguridad. 
              Una vez invitados, recibirán un email para crear su contraseña de acceso.
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <span className="flex items-center justify-center w-8 h-8 bg-blue-900 text-white rounded-full text-sm">1</span>
              Acceder a la Gestión de Usuarios
            </h3>
            <div className="ml-10 space-y-2">
              <p className="text-slate-700">Dirígete al <strong>Dashboard</strong> (panel principal de base44)</p>
              <p className="text-slate-700">Haz clic en la barra lateral → <strong>Usuarios</strong></p>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <span className="flex items-center justify-center w-8 h-8 bg-blue-900 text-white rounded-full text-sm">2</span>
              Invitar Nuevo Usuario
            </h3>
            <div className="ml-10 space-y-2">
              <p className="text-slate-700">Haz clic en el botón <strong>"Invitar Usuario"</strong></p>
              <p className="text-slate-700">Completa el formulario con:</p>
              <ul className="list-disc ml-5 space-y-1 text-slate-700">
                <li><strong>Email del empleado</strong> (obligatorio)</li>
                <li><strong>Nombre completo</strong> (obligatorio)</li>
                <li><strong>Rol:</strong>
                  <ul className="list-circle ml-5 mt-1">
                    <li><strong>Administrador:</strong> Acceso completo a gestión</li>
                    <li><strong>Usuario:</strong> Solo puede registrar trabajos y ver su información</li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <span className="flex items-center justify-center w-8 h-8 bg-blue-900 text-white rounded-full text-sm">3</span>
              El Empleado Recibe Email de Invitación
            </h3>
            <div className="ml-10 space-y-3">
              <div className="bg-gradient-to-r from-green-50 to-green-100 border-l-4 border-green-500 p-4 rounded-r-lg">
                <div className="flex items-start gap-3">
                  <Mail className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-bold text-green-900 mb-2">Email Automático</h4>
                    <p className="text-green-800 text-sm">
                      El empleado recibirá un <strong>email automático</strong> con:
                    </p>
                    <ul className="list-disc ml-5 mt-2 space-y-1 text-green-800 text-sm">
                      <li>Enlace de activación de cuenta</li>
                      <li>Instrucciones para crear su contraseña</li>
                      <li>Enlace directo a la aplicación</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-blue-50 to-blue-100 border-l-4 border-blue-500 p-4 rounded-r-lg">
                <div className="flex items-start gap-3">
                  <Key className="w-6 h-6 text-blue-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-bold text-blue-900 mb-2">Creación de Contraseña</h4>
                    <p className="text-blue-800 text-sm">
                      El empleado debe hacer clic en el enlace del email para:
                    </p>
                    <ul className="list-disc ml-5 mt-2 space-y-1 text-blue-800 text-sm">
                      <li>Crear su contraseña personal</li>
                      <li>Confirmar su cuenta</li>
                      <li>Acceder a la aplicación</li>
                    </ul>
                    <p className="text-blue-700 text-sm mt-3 font-medium">
                      ⚠️ El empleado <strong>debe crear su contraseña</strong> antes de poder iniciar sesión. No puede usar Google para iniciar sesión.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <span className="flex items-center justify-center w-8 h-8 bg-blue-900 text-white rounded-full text-sm">4</span>
              Configurar Datos del Empleado
            </h3>
            <div className="ml-10 space-y-2">
              <p className="text-slate-700">Una vez que el empleado haya creado su contraseña:</p>
              <ol className="list-decimal ml-5 space-y-2 text-slate-700">
                <li>Regresa a <strong>Gestión de Empleados</strong></li>
                <li>Busca al empleado y haz clic en <strong>"Editar"</strong></li>
                <li>Configura:
                  <ul className="list-disc ml-5 mt-1">
                    <li>Profesión</li>
                    <li>Centros asignados</li>
                    <li>Teléfono</li>
                    <li>Horas semanales</li>
                  </ul>
                </li>
                <li>Sube sus documentos en <strong>Gestión de Documentos</strong></li>
              </ol>
            </div>
          </div>

          <div className="bg-gradient-to-r from-teal-50 to-teal-100 border-l-4 border-teal-500 p-4 rounded-r-lg">
            <h3 className="font-bold text-teal-900 mb-2 flex items-center gap-2">
              <CheckCircle className="w-5 h-5" />
              ¡Listo!
            </h3>
            <p className="text-teal-800">
              El empleado ya puede iniciar sesión con su email y contraseña, y comenzar a usar la aplicación.
            </p>
          </div>

          <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-r-lg">
            <h4 className="font-semibold text-amber-900 mb-2">⚠️ Importante</h4>
            <p className="text-sm text-amber-800">
              Si el empleado no recibe el email, pídele que revise su carpeta de spam. 
              Si sigue sin recibirlo, puedes volver a enviar la invitación desde Dashboard → Usuarios.
            </p>
          </div>
        </div>

        <div className="flex justify-end pt-4">
          <Button
            onClick={onClose}
            className="bg-gradient-to-r from-blue-900 to-blue-800 hover:from-blue-800 hover:to-blue-700 text-white px-8 py-6 text-lg"
          >
            Entendido
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}