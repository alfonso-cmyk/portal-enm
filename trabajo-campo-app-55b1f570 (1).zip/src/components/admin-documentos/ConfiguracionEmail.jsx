import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mail } from "lucide-react";

export default function ConfiguracionEmail({ onClose }) {
  const queryClient = useQueryClient();

  const { data: config = [] } = useQuery({
    queryKey: ['configuracion'],
    queryFn: () => base44.entities.ConfiguracionApp.list(),
    initialData: [],
  });

  const emailActual = config.find(c => c.clave === 'email_administracion');
  const [email, setEmail] = useState(emailActual?.valor || '');

  const saveConfigMutation = useMutation({
    mutationFn: async (emailValue) => {
      if (emailActual) {
        return base44.entities.ConfiguracionApp.update(emailActual.id, {
          valor: emailValue
        });
      } else {
        return base44.entities.ConfiguracionApp.create({
          clave: 'email_administracion',
          valor: emailValue,
          descripcion: 'Email donde se reciben las solicitudes de empleados'
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['configuracion'] });
      onClose();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    saveConfigMutation.mutate(email);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5" />
            Configurar Email de Administración
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Email para Recibir Solicitudes</Label>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@empresa.com"
              className="mt-2"
              required
            />
            <p className="text-sm text-slate-600 mt-2">
              Las solicitudes de los empleados se enviarán a este correo electrónico.
            </p>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={saveConfigMutation.isPending}>
              {saveConfigMutation.isPending ? 'Guardando...' : 'Guardar'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}