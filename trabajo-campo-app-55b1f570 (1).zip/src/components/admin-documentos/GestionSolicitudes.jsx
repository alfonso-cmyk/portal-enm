
import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Clock, CheckCircle, XCircle, MessageSquare, Send } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const estadoColors = {
  pendiente: "bg-yellow-100 text-yellow-800",
  en_revision: "bg-blue-100 text-blue-800",
  aprobada: "bg-green-100 text-green-800",
  rechazada: "bg-red-100 text-red-800"
};

export default function GestionSolicitudes() {
  const queryClient = useQueryClient();
  const [conversacionAbierta, setConversacionAbierta] = useState(null);
  const [nuevoMensaje, setNuevoMensaje] = useState("");
  const [respuestas, setRespuestas] = useState({});

  const { data: solicitudes = [] } = useQuery({
    queryKey: ['todas-solicitudes'],
    queryFn: () => base44.entities.Solicitud.list("-created_date"),
    initialData: [],
  });

  const { data: mensajes = [] } = useQuery({
    queryKey: ['mensajes-admin', conversacionAbierta?.id],
    queryFn: () => conversacionAbierta
      ? base44.entities.MensajeSolicitud.filter({
          solicitud_id: conversacionAbierta.id,
        }, "fecha")
      : Promise.resolve([]),
    enabled: !!conversacionAbierta,
    initialData: [],
  });

  const { data: user = null } = useQuery({
    queryKey: ['admin-user'],
    queryFn: () => base44.auth.me(),
  });

  const updateSolicitudMutation = useMutation({
    mutationFn: ({ id, estado, respuesta }) => {
      return base44.entities.Solicitud.update(id, {
        estado,
        respuesta,
        fecha_respuesta: new Date().toISOString().split('T')[0]
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todas-solicitudes'] });
      setRespuestas({});
    },
  });

  const enviarMensajeMutation = useMutation({
    mutationFn: async (mensaje) => {
      if (!user) {
        throw new Error("User not authenticated or data not loaded.");
      }
      return base44.entities.MensajeSolicitud.create({
        solicitud_id: conversacionAbierta.id,
        remitente_id: user.id,
        remitente_nombre: user.full_name,
        es_admin: true,
        mensaje: mensaje,
        fecha: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mensajes-admin'] });
      setNuevoMensaje("");
    },
  });

  const handleResponder = (solicitud, estado) => {
    const respuesta = respuestas[solicitud.id] || '';
    if (!respuesta.trim() && estado !== 'en_revision') {
      alert('Por favor, escribe una respuesta');
      return;
    }
    updateSolicitudMutation.mutate({ id: solicitud.id, estado, respuesta });
  };

  const handleEnviarMensaje = () => {
    if (!nuevoMensaje.trim()) return;
    enviarMensajeMutation.mutate(nuevoMensaje);
  };

  return (
    <>
      <Card className="shadow-xl border-0">
        <CardContent className="p-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            Solicitudes de Empleados ({solicitudes.length})
          </h2>

          <div className="space-y-4">
            {solicitudes.map((solicitud) => (
              <div key={solicitud.id} className="border-2 border-slate-200 rounded-xl p-6 hover:shadow-lg transition-all duration-200">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-bold text-lg text-slate-900">{solicitud.asunto}</h3>
                      <Badge className={estadoColors[solicitud.estado]}>
                        {solicitud.estado.replace(/_/g, ' ')}
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-600 mb-1">
                      <strong>{solicitud.empleado_nombre}</strong> - {solicitud.tipo_solicitud.replace(/_/g, ' ')}
                    </p>
                    <p className="text-slate-700 mb-3">{solicitud.descripcion}</p>
                    <p className="text-xs text-slate-500">
                      Enviada el {format(new Date(solicitud.created_date), "dd MMM yyyy 'a las' HH:mm", { locale: es })}
                    </p>
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setConversacionAbierta(solicitud)}
                    className="flex items-center gap-2 ml-4"
                  >
                    <MessageSquare className="w-4 h-4" />
                    Chat
                  </Button>
                </div>

                {solicitud.estado === 'pendiente' || solicitud.estado === 'en_revision' ? (
                  <div className="space-y-3 pt-4 border-t">
                    <Textarea
                      placeholder="Escribe tu respuesta aquí..."
                      value={respuestas[solicitud.id] || ''}
                      onChange={(e) => setRespuestas({...respuestas, [solicitud.id]: e.target.value})}
                      className="h-24"
                    />
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleResponder(solicitud, 'en_revision')}
                        disabled={updateSolicitudMutation.isPending}
                      >
                        <Clock className="w-4 h-4 mr-1" />
                        En Revisión
                      </Button>
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => handleResponder(solicitud, 'aprobada')}
                        disabled={updateSolicitudMutation.isPending}
                      >
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Aprobar
                      </Button>
                      <Button
                        size="sm"
                        className="bg-red-600 hover:bg-red-700"
                        onClick={() => handleResponder(solicitud, 'rechazada')}
                        disabled={updateSolicitudMutation.isPending}
                      >
                        <XCircle className="w-4 h-4 mr-1" />
                        Rechazar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="pt-4 border-t">
                    <p className="text-sm font-semibold text-slate-900 mb-1">Respuesta:</p>
                    <p className="text-slate-700 bg-slate-50 p-3 rounded-lg">{solicitud.respuesta}</p>
                    {solicitud.fecha_respuesta && (
                      <p className="text-xs text-slate-500 mt-2">
                        Respondida el {format(new Date(solicitud.fecha_respuesta), "dd MMM yyyy", { locale: es })}
                      </p>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Modal de conversación */}
      {conversacionAbierta && (
        <Dialog open={true} onOpenChange={() => setConversacionAbierta(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh] flex flex-col">
            <DialogHeader>
              <DialogTitle>
                Conversación con {conversacionAbierta.empleado_nombre}
                <Badge className={`ml-3 ${estadoColors[conversacionAbierta.estado]}`}>
                  {conversacionAbierta.estado.replace(/_/g, ' ')}
                </Badge>
              </DialogTitle>
            </DialogHeader>

            <div className="flex-1 overflow-y-auto space-y-3 pr-2 py-4"> {/* Added py-4 for padding */}
              {mensajes.length === 0 && (
                <p className="text-center text-slate-500 text-sm">No hay mensajes en esta conversación.</p>
              )}
              {mensajes.map((mensaje) => (
                <div
                  key={mensaje.id}
                  className={`flex ${mensaje.es_admin ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[75%] rounded-lg p-4 ${
                      mensaje.es_admin
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 text-slate-900'
                    }`}
                  >
                    <p className="text-sm font-semibold mb-1">{mensaje.remitente_nombre}</p>
                    <p className="text-sm whitespace-pre-wrap">{mensaje.mensaje}</p>
                    <p className="text-xs mt-2 opacity-70">
                      {format(new Date(mensaje.fecha), "dd MMM HH:mm", { locale: es })}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Input de nuevo mensaje */}
            <div className="flex gap-2 pt-4 border-t">
              <Textarea
                placeholder="Escribe tu mensaje..."
                value={nuevoMensaje}
                onChange={(e) => setNuevoMensaje(e.target.value)}
                className="flex-1"
                rows={3}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleEnviarMensaje();
                  }
                }}
              />
              <Button
                onClick={handleEnviarMensaje}
                disabled={!nuevoMensaje.trim() || enviarMensajeMutation.isPending}
                className="bg-indigo-600 hover:bg-indigo-700"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
