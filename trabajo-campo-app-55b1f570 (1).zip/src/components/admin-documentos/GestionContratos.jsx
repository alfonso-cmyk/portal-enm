import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";

export default function GestionContratos({ empleados }) {
  const queryClient = useQueryClient();
  const [modalAbierto, setModalAbierto] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    empleado_id: '',
    tipo_contrato: '',
    fecha_inicio: '',
    fecha_fin: '',
    archivo: null,
    activo: true
  });

  const { data: contratos = [] } = useQuery({
    queryKey: ['todos-contratos'],
    queryFn: () => base44.entities.Contrato.list("-fecha_inicio"),
    initialData: [],
  });

  const createContratoMutation = useMutation({
    mutationFn: async (data) => {
      setUploading(true);
      const { file_url } = await base44.integrations.Core.UploadFile({ file: data.archivo });
      
      const empleado = empleados.find(e => e.id === data.empleado_id);
      
      return base44.entities.Contrato.create({
        empleado_id: data.empleado_id,
        empleado_nombre: empleado?.full_name || '',
        tipo_contrato: data.tipo_contrato,
        fecha_inicio: data.fecha_inicio,
        fecha_fin: data.fecha_fin || undefined,
        archivo_url: file_url,
        activo: data.activo
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todos-contratos'] });
      setModalAbierto(false);
      setFormData({ empleado_id: '', tipo_contrato: '', fecha_inicio: '', fecha_fin: '', archivo: null, activo: true });
      setUploading(false);
    },
  });

  const deleteContratoMutation = useMutation({
    mutationFn: (id) => base44.entities.Contrato.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todos-contratos'] });
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    createContratoMutation.mutate(formData);
  };

  return (
    <>
      <Card className="shadow-xl border-0">
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-900">Contratos Registrados ({contratos.length})</h2>
            <Button
              onClick={() => setModalAbierto(true)}
              className="bg-gradient-to-r from-teal-500 to-teal-600"
            >
              <Plus className="w-4 h-4 mr-2" />
              Nuevo Contrato
            </Button>
          </div>

          <div className="space-y-3">
            {contratos.map((contrato) => (
              <div key={contrato.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <p className="font-semibold text-slate-900">{contrato.empleado_nombre}</p>
                    <Badge className={contrato.activo ? "bg-green-100 text-green-800" : "bg-slate-100 text-slate-800"}>
                      {contrato.activo ? 'Activo' : 'Inactivo'}
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-600">
                    {contrato.tipo_contrato} - Desde {contrato.fecha_inicio}
                    {contrato.fecha_fin && ` hasta ${contrato.fecha_fin}`}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.open(contrato.archivo_url, '_blank')}
                  >
                    Ver
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      if (confirm('¿Eliminar este contrato?')) {
                        deleteContratoMutation.mutate(contrato.id);
                      }
                    }}
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {modalAbierto && (
        <Dialog open={true} onOpenChange={setModalAbierto}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Registrar Nuevo Contrato</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Empleado *</Label>
                <Select
                  value={formData.empleado_id}
                  onValueChange={(value) => setFormData({...formData, empleado_id: value})}
                  required
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Selecciona empleado" />
                  </SelectTrigger>
                  <SelectContent>
                    {empleados.map(emp => (
                      <SelectItem key={emp.id} value={emp.id}>{emp.full_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Tipo de Contrato *</Label>
                <Select
                  value={formData.tipo_contrato}
                  onValueChange={(value) => setFormData({...formData, tipo_contrato: value})}
                  required
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Selecciona tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="indefinido">Indefinido</SelectItem>
                    <SelectItem value="temporal">Temporal</SelectItem>
                    <SelectItem value="practicas">Prácticas</SelectItem>
                    <SelectItem value="formacion">Formación</SelectItem>
                    <SelectItem value="otro">Otro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Fecha Inicio *</Label>
                  <Input
                    type="date"
                    value={formData.fecha_inicio}
                    onChange={(e) => setFormData({...formData, fecha_inicio: e.target.value})}
                    className="mt-2"
                    required
                  />
                </div>
                <div>
                  <Label>Fecha Fin (opcional)</Label>
                  <Input
                    type="date"
                    value={formData.fecha_fin}
                    onChange={(e) => setFormData({...formData, fecha_fin: e.target.value})}
                    className="mt-2"
                  />
                </div>
              </div>

              <div>
                <Label>Archivo PDF *</Label>
                <Input
                  type="file"
                  accept=".pdf"
                  onChange={(e) => setFormData({...formData, archivo: e.target.files[0]})}
                  className="mt-2"
                  required
                />
              </div>

              <div className="flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => setModalAbierto(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={uploading}>
                  {uploading ? 'Subiendo...' : 'Registrar Contrato'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}