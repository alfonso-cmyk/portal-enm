import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function GestionVacaciones({ empleados }) {
  const queryClient = useQueryClient();
  const [modalAbierto, setModalAbierto] = useState(false);
  const [editando, setEditando] = useState(null);
  const [formData, setFormData] = useState({
    empleado_id: '',
    anio: new Date().getFullYear(),
    dias_totales: 22,
    dias_usados: 0,
    dias_pendientes: 22
  });

  const { data: vacaciones = [] } = useQuery({
    queryKey: ['todas-vacaciones'],
    queryFn: () => base44.entities.Vacacion.list("-anio"),
    initialData: [],
  });

  const createVacacionMutation = useMutation({
    mutationFn: (data) => {
      const empleado = empleados.find(e => e.id === data.empleado_id);
      return base44.entities.Vacacion.create({
        ...data,
        empleado_nombre: empleado?.full_name || '',
        dias_pendientes: data.dias_totales - data.dias_usados
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todas-vacaciones'] });
      setModalAbierto(false);
      resetForm();
    },
  });

  const updateVacacionMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Vacacion.update(id, {
      ...data,
      dias_pendientes: data.dias_totales - data.dias_usados
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todas-vacaciones'] });
      setModalAbierto(false);
      resetForm();
    },
  });

  const deleteVacacionMutation = useMutation({
    mutationFn: (id) => base44.entities.Vacacion.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todas-vacaciones'] });
    },
  });

  const resetForm = () => {
    setFormData({ empleado_id: '', anio: new Date().getFullYear(), dias_totales: 22, dias_usados: 0, dias_pendientes: 22 });
    setEditando(null);
  };

  const handleEditar = (vacacion) => {
    setEditando(vacacion);
    setFormData({
      empleado_id: vacacion.empleado_id,
      anio: vacacion.anio,
      dias_totales: vacacion.dias_totales,
      dias_usados: vacacion.dias_usados,
      dias_pendientes: vacacion.dias_pendientes
    });
    setModalAbierto(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editando) {
      updateVacacionMutation.mutate({ id: editando.id, data: formData });
    } else {
      createVacacionMutation.mutate(formData);
    }
  };

  return (
    <>
      <Card className="shadow-xl border-0">
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-900">Gestión de Vacaciones</h2>
            <Button
              onClick={() => { resetForm(); setModalAbierto(true); }}
              className="bg-gradient-to-r from-purple-600 to-purple-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Configurar Vacaciones
            </Button>
          </div>

          <div className="space-y-3">
            {vacaciones.map((vac) => (
              <div key={vac.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
                <div>
                  <p className="font-semibold text-slate-900">{vac.empleado_nombre} - {vac.anio}</p>
                  <p className="text-sm text-slate-600">
                    Total: {vac.dias_totales} días | Usados: {vac.dias_usados} | Pendientes: {vac.dias_pendientes}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => handleEditar(vac)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      if (confirm('¿Eliminar este registro?')) {
                        deleteVacacionMutation.mutate(vac.id);
                      }
                    }}
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {modalAbierto && (
        <Dialog open={true} onOpenChange={() => { setModalAbierto(false); resetForm(); }}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editando ? 'Editar' : 'Configurar'} Vacaciones</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Empleado *</Label>
                <Select
                  value={formData.empleado_id}
                  onValueChange={(value) => setFormData({...formData, empleado_id: value})}
                  disabled={!!editando}
                  required
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Selecciona empleado" />
                  </SelectTrigger>
                  <SelectContent>
                    {empleados.map(emp => (
                      <SelectItem key={emp.id} value={emp.id}>{emp.full_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Año *</Label>
                <Input
                  type="number"
                  value={formData.anio}
                  onChange={(e) => setFormData({...formData, anio: parseInt(e.target.value)})}
                  className="mt-2"
                  required
                />
              </div>

              <div>
                <Label>Días Totales *</Label>
                <Input
                  type="number"
                  value={formData.dias_totales}
                  onChange={(e) => setFormData({...formData, dias_totales: parseInt(e.target.value)})}
                  className="mt-2"
                  required
                />
              </div>

              <div>
                <Label>Días Usados *</Label>
                <Input
                  type="number"
                  value={formData.dias_usados}
                  onChange={(e) => setFormData({...formData, dias_usados: parseInt(e.target.value)})}
                  className="mt-2"
                  required
                />
              </div>

              <div className="flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => { setModalAbierto(false); resetForm(); }}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {editando ? 'Actualizar' : 'Crear'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}