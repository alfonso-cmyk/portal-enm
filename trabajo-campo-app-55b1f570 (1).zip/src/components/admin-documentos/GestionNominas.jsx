import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Upload, FileText, Eye, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";

export default function GestionNominas({ empleados }) {
  const queryClient = useQueryClient();
  const [empleadoSeleccionado, setEmpleadoSeleccionado] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    mes: '',
    archivo: null
  });

  const { data: todasNominas = [] } = useQuery({
    queryKey: ['todas-nominas'],
    queryFn: () => base44.entities.Nomina.list("-mes"),
    initialData: [],
  });

  const empleadosActivos = empleados.filter(e => e.activo !== false && e.role !== 'admin');

  const createNominaMutation = useMutation({
    mutationFn: async (data) => {
      setUploading(true);
      const { file_url } = await base44.integrations.Core.UploadFile({ file: data.archivo });
      
      return base44.entities.Nomina.create({
        empleado_id: empleadoSeleccionado.id,
        empleado_nombre: empleadoSeleccionado.full_name,
        mes: data.mes,
        archivo_url: file_url,
        importe_bruto: 0,
        importe_neto: 0,
        notas: ''
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todas-nominas'] });
      setEmpleadoSeleccionado(null);
      setFormData({ mes: '', archivo: null });
      setUploading(false);
    },
  });

  const deleteNominaMutation = useMutation({
    mutationFn: (id) => base44.entities.Nomina.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todas-nominas'] });
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.archivo) {
      alert('Por favor, selecciona un archivo PDF');
      return;
    }
    createNominaMutation.mutate(formData);
  };

  const getNominasEmpleado = (empleadoId) => {
    return todasNominas.filter(n => n.empleado_id === empleadoId);
  };

  return (
    <>
      <Card className="shadow-xl border-0">
        <CardContent className="p-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Gestión de Nóminas por Empleado</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {empleadosActivos.map((empleado) => {
              const nominasEmpleado = getNominasEmpleado(empleado.id);
              
              return (
                <Card key={empleado.id} className="shadow-lg border-0 hover:shadow-xl transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-4">
                      <Avatar className="w-12 h-12 bg-gradient-to-br from-[#24c4ba] to-[#1ca89f]">
                        {empleado.foto_perfil ? (
                          <AvatarImage src={empleado.foto_perfil} />
                        ) : null}
                        <AvatarFallback className="bg-transparent text-white font-bold">
                          {empleado.full_name?.charAt(0)?.toUpperCase() || 'U'}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="font-bold text-[#1a1a1a]">{empleado.full_name}</h3>
                        <p className="text-sm text-slate-600">{empleado.profesion}</p>
                      </div>
                    </div>

                    <div className="mb-3">
                      <Badge className="bg-blue-100 text-blue-800">
                        {nominasEmpleado.length} nómina{nominasEmpleado.length !== 1 ? 's' : ''}
                      </Badge>
                    </div>

                    <Button
                      onClick={() => setEmpleadoSeleccionado(empleado)}
                      className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Subir Nómina
                    </Button>

                    {nominasEmpleado.length > 0 && (
                      <div className="mt-4 space-y-2">
                        <p className="text-xs font-semibold text-slate-600 uppercase">Nóminas subidas:</p>
                        {nominasEmpleado.slice(0, 3).map((nomina) => (
                          <div key={nomina.id} className="flex items-center justify-between text-sm bg-slate-50 p-2 rounded">
                            <span className="font-medium">{nomina.mes}</span>
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => window.open(nomina.archivo_url, '_blank')}
                                className="h-7 w-7"
                              >
                                <Eye className="w-3 h-3" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  if (confirm('¿Eliminar esta nómina?')) {
                                    deleteNominaMutation.mutate(nomina.id);
                                  }
                                }}
                                className="h-7 w-7 text-red-600"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        ))}
                        {nominasEmpleado.length > 3 && (
                          <p className="text-xs text-slate-500">
                            +{nominasEmpleado.length - 3} más...
                          </p>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {empleadoSeleccionado && (
        <Dialog open={true} onOpenChange={() => setEmpleadoSeleccionado(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Subir Nómina - {empleadoSeleccionado.full_name}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Mes y Año *</Label>
                <Input
                  type="month"
                  value={formData.mes}
                  onChange={(e) => setFormData({...formData, mes: e.target.value})}
                  className="mt-2"
                  required
                />
                <p className="text-xs text-slate-500 mt-1">
                  Selecciona el mes y año de la nómina
                </p>
              </div>

              <div>
                <Label>Archivo PDF *</Label>
                <Input
                  type="file"
                  accept=".pdf"
                  onChange={(e) => setFormData({...formData, archivo: e.target.files[0]})}
                  className="mt-2"
                  required
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setEmpleadoSeleccionado(null)}
                >
                  Cancelar
                </Button>
                <Button 
                  type="submit" 
                  disabled={uploading}
                  className="bg-gradient-to-r from-blue-600 to-blue-700"
                >
                  {uploading ? 'Subiendo...' : 'Subir Nómina'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}