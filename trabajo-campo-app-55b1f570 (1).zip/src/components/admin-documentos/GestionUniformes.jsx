import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Plus, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

const TIPOS_UNIFORME = [
  "Camiseta blanca",
  "Camiseta negra",
  "Polo",
  "Jersey",
  "Forro polar",
  "Pantalón largo",
  "Chubasquero",
  "Uniforme de limpieza",
  "Camiseta socorrista",
  "Bañador de socorrista",
  "Gorra",
  "Sudadera",
  "Botas de trabajo"
];

const TALLAS_ROPA = ["XS", "S", "M", "L", "XL", "XXL"];
const TALLAS_BOTAS = ["36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49"];

export default function GestionUniformes({ empleados }) {
  const queryClient = useQueryClient();
  const [modalAbierto, setModalAbierto] = useState(false);
  const [formData, setFormData] = useState({
    empleado_id: '',
    tipo: '',
    talla: '',
    cantidad: 1,
    fecha_entrega: new Date().toISOString().split('T')[0],
    estado: 'nuevo'
  });

  const { data: uniformes = [] } = useQuery({
    queryKey: ['todos-uniformes'],
    queryFn: () => base44.entities.Uniforme.list("-fecha_entrega"),
    initialData: [],
  });

  const createUniformeMutation = useMutation({
    mutationFn: (data) => {
      const empleado = empleados.find(e => e.id === data.empleado_id);
      return base44.entities.Uniforme.create({
        ...data,
        empleado_nombre: empleado?.full_name || ''
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todos-uniformes'] });
      setModalAbierto(false);
      setFormData({ 
        empleado_id: '', 
        tipo: '', 
        talla: '', 
        cantidad: 1, 
        fecha_entrega: new Date().toISOString().split('T')[0], 
        estado: 'nuevo' 
      });
      alert('✅ Uniforme registrado correctamente');
    },
  });

  const deleteUniformeMutation = useMutation({
    mutationFn: (id) => base44.entities.Uniforme.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todos-uniformes'] });
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    createUniformeMutation.mutate(formData);
  };

  const esBotas = formData.tipo === "Botas de trabajo";
  const tallasDisponibles = esBotas ? TALLAS_BOTAS : TALLAS_ROPA;

  return (
    <>
      <Card className="shadow-xl border-0">
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-900">Gestión de Uniformes</h2>
            <Button
              onClick={() => setModalAbierto(true)}
              className="bg-gradient-to-r from-green-600 to-green-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Registrar Uniforme
            </Button>
          </div>

          <div className="space-y-3">
            {uniformes.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                No hay uniformes registrados
              </div>
            ) : (
              uniformes.map((uniforme) => (
                <div key={uniforme.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
                  <div>
                    <p className="font-semibold text-slate-900">{uniforme.empleado_nombre}</p>
                    <p className="text-sm text-slate-600">
                      {uniforme.tipo} - Talla {uniforme.talla} - Cantidad: {uniforme.cantidad} - {uniforme.fecha_entrega}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      if (confirm('¿Eliminar este registro?')) {
                        deleteUniformeMutation.mutate(uniforme.id);
                      }
                    }}
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </Button>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {modalAbierto && (
        <Dialog open={true} onOpenChange={setModalAbierto}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Registrar Uniforme</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Empleado *</Label>
                <Select
                  value={formData.empleado_id}
                  onValueChange={(value) => setFormData({...formData, empleado_id: value})}
                  required
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Selecciona empleado" />
                  </SelectTrigger>
                  <SelectContent>
                    {empleados.map(emp => (
                      <SelectItem key={emp.id} value={emp.id}>{emp.full_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Tipo de Uniforme *</Label>
                <Select
                  value={formData.tipo}
                  onValueChange={(value) => setFormData({...formData, tipo: value, talla: ''})}
                  required
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Selecciona tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    {TIPOS_UNIFORME.map(tipo => (
                      <SelectItem key={tipo} value={tipo}>{tipo}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {formData.tipo && (
                <div>
                  <Label>Talla *</Label>
                  <Select
                    value={formData.talla}
                    onValueChange={(value) => setFormData({...formData, talla: value})}
                    required
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Selecciona talla" />
                    </SelectTrigger>
                    <SelectContent>
                      {tallasDisponibles.map(talla => (
                        <SelectItem key={talla} value={talla}>{talla}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Cantidad *</Label>
                  <Input
                    type="number"
                    value={formData.cantidad}
                    onChange={(e) => setFormData({...formData, cantidad: parseInt(e.target.value)})}
                    min="1"
                    className="mt-2"
                    required
                  />
                </div>
                <div>
                  <Label>Fecha de Entrega *</Label>
                  <Input
                    type="date"
                    value={formData.fecha_entrega}
                    onChange={(e) => setFormData({...formData, fecha_entrega: e.target.value})}
                    className="mt-2"
                    required
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setModalAbierto(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-gradient-to-r from-green-600 to-green-700">
                  Registrar
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}