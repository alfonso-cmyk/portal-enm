import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function GestionMaterial({ empleados }) {
  const queryClient = useQueryClient();
  const [modalAbierto, setModalAbierto] = useState(false);
  const [formData, setFormData] = useState({
    empleado_id: '',
    descripcion: '',
    tipo: '',
    cantidad: 1,
    fecha_entrega: new Date().toISOString().split('T')[0],
    estado: 'nuevo'
  });

  const { data: materiales = [] } = useQuery({
    queryKey: ['todos-materiales'],
    queryFn: () => base44.entities.Material.list("-fecha_entrega"),
    initialData: [],
  });

  const createMaterialMutation = useMutation({
    mutationFn: (data) => {
      const empleado = empleados.find(e => e.id === data.empleado_id);
      return base44.entities.Material.create({
        ...data,
        empleado_nombre: empleado?.full_name || ''
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todos-materiales'] });
      setModalAbierto(false);
      setFormData({ empleado_id: '', descripcion: '', tipo: '', cantidad: 1, fecha_entrega: new Date().toISOString().split('T')[0], estado: 'nuevo' });
    },
  });

  const deleteMaterialMutation = useMutation({
    mutationFn: (id) => base44.entities.Material.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todos-materiales'] });
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    createMaterialMutation.mutate(formData);
  };

  return (
    <>
      <Card className="shadow-xl border-0">
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-900">Gestión de Material</h2>
            <Button
              onClick={() => setModalAbierto(true)}
              className="bg-gradient-to-r from-amber-500 to-amber-600"
            >
              <Plus className="w-4 h-4 mr-2" />
              Registrar Material
            </Button>
          </div>

          <div className="space-y-3">
            {materiales.map((material) => (
              <div key={material.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
                <div>
                  <p className="font-semibold text-slate-900">{material.empleado_nombre}</p>
                  <p className="text-sm text-slate-600">
                    {material.descripcion} - {material.tipo} - Cantidad: {material.cantidad} - {material.fecha_entrega}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    if (confirm('¿Eliminar este registro?')) {
                      deleteMaterialMutation.mutate(material.id);
                    }
                  }}
                >
                  <Trash2 className="w-4 h-4 text-red-600" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {modalAbierto && (
        <Dialog open={true} onOpenChange={setModalAbierto}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Registrar Material</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Empleado *</Label>
                <Select
                  value={formData.empleado_id}
                  onValueChange={(value) => setFormData({...formData, empleado_id: value})}
                  required
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Selecciona empleado" />
                  </SelectTrigger>
                  <SelectContent>
                    {empleados.map(emp => (
                      <SelectItem key={emp.id} value={emp.id}>{emp.full_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Tipo *</Label>
                <Select
                  value={formData.tipo}
                  onValueChange={(value) => setFormData({...formData, tipo: value})}
                  required
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Selecciona tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="herramienta">Herramienta</SelectItem>
                    <SelectItem value="equipo_proteccion">Equipo de Protección</SelectItem>
                    <SelectItem value="producto_limpieza">Producto de Limpieza</SelectItem>
                    <SelectItem value="otro">Otro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Descripción *</Label>
                <Textarea
                  value={formData.descripcion}
                  onChange={(e) => setFormData({...formData, descripcion: e.target.value})}
                  placeholder="Describe el material..."
                  className="mt-2"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Cantidad *</Label>
                  <Input
                    type="number"
                    value={formData.cantidad}
                    onChange={(e) => setFormData({...formData, cantidad: parseInt(e.target.value)})}
                    min="1"
                    className="mt-2"
                    required
                  />
                </div>
                <div>
                  <Label>Fecha de Entrega *</Label>
                  <Input
                    type="date"
                    value={formData.fecha_entrega}
                    onChange={(e) => setFormData({...formData, fecha_entrega: e.target.value})}
                    className="mt-2"
                    required
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => setModalAbierto(false)}>
                  Cancelar
                </Button>
                <Button type="submit">Registrar</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}