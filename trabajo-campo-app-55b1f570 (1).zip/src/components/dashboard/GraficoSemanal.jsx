import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { startOfWeek, endOfWeek, eachDayOfInterval, format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function GraficoSemanal({ registros }) {
  const hoy = new Date();
  const inicioSemana = startOfWeek(hoy, { locale: es, weekStartsOn: 1 });
  const finSemana = endOfWeek(hoy, { locale: es, weekStartsOn: 1 });
  const diasSemana = eachDayOfInterval({ start: inicioSemana, end: finSemana });

  const data = diasSemana.map(dia => {
    const fechaStr = format(dia, 'yyyy-MM-dd');
    const registrosDia = registros.filter(r => r.fecha === fechaStr);
    const horas = registrosDia.reduce((sum, r) => sum + (r.horas_trabajadas || 0), 0);
    
    return {
      dia: format(dia, 'EEE', { locale: es }),
      horas: parseFloat(horas.toFixed(1))
    };
  });

  return (
    <Card className="shadow-lg border-0">
      <CardHeader className="bg-gradient-to-r from-teal-500 to-teal-600 text-white rounded-t-xl">
        <CardTitle>Horas Esta Semana</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey="dia" stroke="#64748b" />
            <YAxis stroke="#64748b" />
            <Tooltip
              contentStyle={{
                backgroundColor: 'white',
                border: '1px solid #e2e8f0',
                borderRadius: '8px'
              }}
            />
            <Bar dataKey="horas" fill="url(#colorGradient)" radius={[8, 8, 0, 0]} />
            <defs>
              <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#14b8a6" />
                <stop offset="100%" stopColor="#0d9488" />
              </linearGradient>
            </defs>
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}