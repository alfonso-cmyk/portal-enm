import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { HardDrive, User, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function EstadisticasAlmacenamiento({ registros, empleados }) {
  // Calcular espacio total usado
  const espacioTotal = registros.reduce((sum, r) => {
    const antes = r.foto_antes_size || 0;
    const despues = r.foto_despues_size || 0;
    return sum + antes + despues;
  }, 0);

  // Calcular espacio por empleado
  const espacioPorEmpleado = empleados
    .map(emp => {
      const registrosEmpleado = registros.filter(r => r.empleado_id === emp.id);
      const espacio = registrosEmpleado.reduce((sum, r) => {
        return sum + (r.foto_antes_size || 0) + (r.foto_despues_size || 0);
      }, 0);
      
      return {
        id: emp.id,
        nombre: emp.full_name,
        espacio: espacio,
        espacioMB: (espacio / 1024 / 1024).toFixed(2),
        registros: registrosEmpleado.length,
        promedioMB: registrosEmpleado.length > 0 ? (espacio / 1024 / 1024 / registrosEmpleado.length).toFixed(2) : 0
      };
    })
    .filter(e => e.espacio > 0)
    .sort((a, b) => b.espacio - a.espacio);

  const espacioTotalMB = (espacioTotal / 1024 / 1024).toFixed(2);
  const espacioTotalGB = (espacioTotal / 1024 / 1024 / 1024).toFixed(2);
  
  // Límite estimado (ajusta según tu plan)
  const limiteGB = 10; // Por ejemplo, 10GB
  const porcentajeUsado = (parseFloat(espacioTotalGB) / limiteGB) * 100;

  const formatBytes = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="space-y-6">
      {/* Resumen General */}
      <Card className="shadow-lg border-0">
        <CardHeader className="bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-t-xl">
          <CardTitle className="flex items-center gap-2">
            <HardDrive className="w-5 h-5" />
            Almacenamiento Total
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-3xl font-bold text-indigo-600">{espacioTotalGB} GB</p>
                <p className="text-sm text-slate-600">de {limiteGB} GB disponibles</p>
              </div>
              <Badge className={`${porcentajeUsado > 80 ? 'bg-red-500' : porcentajeUsado > 60 ? 'bg-yellow-500' : 'bg-green-500'} text-white text-lg px-4 py-2`}>
                {porcentajeUsado.toFixed(1)}%
              </Badge>
            </div>
            
            <Progress value={porcentajeUsado} className="h-3" />
            
            <div className="grid grid-cols-3 gap-4 pt-4 border-t">
              <div className="text-center">
                <p className="text-2xl font-bold text-slate-900">{registros.length}</p>
                <p className="text-xs text-slate-600">Registros totales</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-slate-900">{espacioTotalMB} MB</p>
                <p className="text-xs text-slate-600">Espacio usado</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-slate-900">
                  {registros.length > 0 ? (espacioTotal / registros.length / 1024 / 1024).toFixed(2) : 0} MB
                </p>
                <p className="text-xs text-slate-600">Promedio/registro</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Espacio por Empleado */}
      <Card className="shadow-lg border-0">
        <CardHeader className="bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-t-xl">
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5" />
            Almacenamiento por Empleado
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-3">
            {espacioPorEmpleado.slice(0, 10).map((emp, index) => (
              <div key={emp.id} className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-purple-100 text-purple-700 font-bold text-sm">
                  #{index + 1}
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-slate-900">{emp.nombre}</p>
                  <p className="text-xs text-slate-600">
                    {emp.registros} registros • {emp.promedioMB} MB/registro
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-purple-600">{emp.espacioMB} MB</p>
                  <p className="text-xs text-slate-500">
                    {((emp.espacio / espacioTotal) * 100).toFixed(1)}% del total
                  </p>
                </div>
              </div>
            ))}
            
            {espacioPorEmpleado.length === 0 && (
              <p className="text-center text-slate-500 py-8">
                No hay datos de almacenamiento aún
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recomendaciones */}
      {porcentajeUsado > 80 && (
        <Card className="shadow-lg border-2 border-red-200">
          <CardContent className="p-6">
            <div className="flex items-start gap-3">
              <TrendingUp className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-red-900 mb-2">⚠️ Almacenamiento casi lleno</h3>
                <p className="text-sm text-red-800 mb-3">
                  Estás usando más del 80% de tu espacio disponible. Considera:
                </p>
                <ul className="text-sm text-red-700 space-y-1 list-disc ml-5">
                  <li>Eliminar registros antiguos innecesarios</li>
                  <li>Exportar y archivar trabajos de meses anteriores</li>
                  <li>Contactar con soporte para ampliar tu plan</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}