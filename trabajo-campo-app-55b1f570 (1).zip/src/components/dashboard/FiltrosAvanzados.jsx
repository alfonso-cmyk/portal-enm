import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Filter } from "lucide-react";

export default function FiltrosAvanzados({ filtros, setFiltros, empleados, centros }) {
  return (
    <Card className="shadow-lg border-0 mb-8">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="w-5 h-5 text-slate-600" />
          <h3 className="font-semibold text-lg text-slate-900">Filtros</h3>
        </div>
        <div className="grid md:grid-cols-5 gap-4">
          <div>
            <Label className="text-sm text-slate-600 mb-2">Empleado</Label>
            <Select value={filtros.empleado} onValueChange={(value) => setFiltros({...filtros, empleado: value})}>
              <SelectTrigger className="rounded-lg">
                <SelectValue placeholder="Todos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                {empleados.map(emp => (
                  <SelectItem key={emp.id} value={emp.id}>{emp.full_name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm text-slate-600 mb-2">Centro</Label>
            <Select value={filtros.centro} onValueChange={(value) => setFiltros({...filtros, centro: value})}>
              <SelectTrigger className="rounded-lg">
                <SelectValue placeholder="Todos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                {centros.map(centro => (
                  <SelectItem key={centro.id} value={centro.id}>{centro.nombre}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm text-slate-600 mb-2">Estado</Label>
            <Select value={filtros.estado} onValueChange={(value) => setFiltros({...filtros, estado: value})}>
              <SelectTrigger className="rounded-lg">
                <SelectValue placeholder="Todos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                <SelectItem value="pendiente">Pendiente</SelectItem>
                <SelectItem value="aprobado">Aprobado</SelectItem>
                <SelectItem value="modificado">Modificado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm text-slate-600 mb-2">Fecha Inicio</Label>
            <Input
              type="date"
              value={filtros.fecha_inicio}
              onChange={(e) => setFiltros({...filtros, fecha_inicio: e.target.value})}
              className="rounded-lg"
            />
          </div>

          <div>
            <Label className="text-sm text-slate-600 mb-2">Fecha Fin</Label>
            <Input
              type="date"
              value={filtros.fecha_fin}
              onChange={(e) => setFiltros({...filtros, fecha_fin: e.target.value})}
              className="rounded-lg"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}