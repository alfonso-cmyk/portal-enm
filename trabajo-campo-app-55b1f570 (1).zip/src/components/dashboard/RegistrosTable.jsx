import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { Eye, Trash2, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function RegistrosTable({ registros, isLoading, onEliminar, onNotificar }) {
  const [selectedRegistro, setSelectedRegistro] = useState(null);

  const estadoColors = {
    pendiente: "bg-yellow-100 text-yellow-800 border-yellow-200",
    aprobado: "bg-green-100 text-green-800 border-green-200",
    modificado: "bg-blue-100 text-blue-800 border-blue-200"
  };

  return (
    <>
      <Card className="shadow-lg border-0">
        <CardHeader className="bg-gradient-to-r from-blue-900 to-blue-800 text-white rounded-t-xl">
          <CardTitle>Todos los Trabajos Realizados</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50">
                  <TableHead>Empleado</TableHead>
                  <TableHead>Fecha</TableHead>
                  <TableHead>Centro</TableHead>
                  <TableHead>Horas</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-900 mx-auto" />
                    </TableCell>
                  </TableRow>
                ) : registros.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-slate-500">
                      No hay registros disponibles
                    </TableCell>
                  </TableRow>
                ) : (
                  registros.slice(0, 15).map((registro) => (
                    <TableRow key={registro.id} className="hover:bg-slate-50 transition-colors">
                      <TableCell className="font-medium">{registro.empleado_nombre}</TableCell>
                      <TableCell>
                        {format(new Date(registro.fecha), "dd MMM yyyy", { locale: es })}
                      </TableCell>
                      <TableCell>{registro.centro_nombre}</TableCell>
                      <TableCell className="font-semibold text-teal-600">
                        {registro.horas_trabajadas?.toFixed(1)}h
                      </TableCell>
                      <TableCell>
                        <Badge className={`${estadoColors[registro.estado]} border`}>
                          {registro.estado}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setSelectedRegistro(registro)}
                            title="Ver detalles"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => onNotificar(registro)}
                            className="text-blue-600 hover:text-blue-700"
                            title="Enviar notificación"
                          >
                            <MessageSquare className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => onEliminar(registro)}
                            className="text-red-600 hover:text-red-700"
                            title="Eliminar"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {selectedRegistro && (
        <Dialog open={!!selectedRegistro} onOpenChange={() => setSelectedRegistro(null)}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Detalle del Registro</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-slate-600">Empleado</p>
                  <p className="font-semibold">{selectedRegistro.empleado_nombre}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Profesión</p>
                  <p className="font-semibold">{selectedRegistro.profesion}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Centro</p>
                  <p className="font-semibold">{selectedRegistro.centro_nombre}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Ubicación</p>
                  <p className="font-semibold">{selectedRegistro.ubicacion}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Fecha</p>
                  <p className="font-semibold">
                    {format(new Date(selectedRegistro.fecha), "dd MMMM yyyy", { locale: es })}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-slate-600">Horario</p>
                  <p className="font-semibold">
                    {selectedRegistro.hora_inicio} - {selectedRegistro.hora_fin}
                  </p>
                </div>
              </div>
              
              <div>
                <p className="text-sm text-slate-600 mb-2">Descripción del Trabajo</p>
                <p className="bg-slate-50 p-3 rounded-lg">{selectedRegistro.descripcion_trabajo}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {selectedRegistro.foto_antes && (
                  <div>
                    <p className="text-sm text-slate-600 mb-2">Foto Antes</p>
                    <img 
                      src={selectedRegistro.foto_antes} 
                      alt="Antes" 
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  </div>
                )}
                {selectedRegistro.foto_despues && (
                  <div>
                    <p className="text-sm text-slate-600 mb-2">Foto Después</p>
                    <img 
                      src={selectedRegistro.foto_despues} 
                      alt="Después" 
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  </div>
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}