import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { MessageSquare, Send, Clock, CheckCircle, XCircle } from "lucide-react";
import { format, parseISO } from "date-fns";
import { es } from "date-fns/locale";

const estadoColors = {
  pendiente: "bg-yellow-100 text-yellow-800",
  aprobada: "bg-green-100 text-green-800",
  rechazada: "bg-red-100 text-red-800"
};

const estadoIcons = {
  pendiente: Clock,
  aprobada: CheckCircle,
  rechazada: XCircle
};

export default function ListaSolicitudesVacaciones({ user, solicitudes = [] }) {
  const queryClient = useQueryClient();
  const [conversacionAbierta, setConversacionAbierta] = useState(null);
  const [nuevoMensaje, setNuevoMensaje] = useState("");

  const { data: mensajes = [] } = useQuery({
    queryKey: ['mensajes-vacaciones', conversacionAbierta?.id],
    queryFn: () => conversacionAbierta 
      ? base44.entities.MensajeSolicitud.filter({ 
          solicitud_id: conversacionAbierta.id,
          tipo_solicitud: 'vacaciones'
        }, "fecha")
      : Promise.resolve([]),
    enabled: !!conversacionAbierta,
    initialData: [],
  });

  const enviarMensajeMutation = useMutation({
    mutationFn: async (mensaje) => {
      return base44.entities.MensajeSolicitud.create({
        solicitud_id: conversacionAbierta.id,
        tipo_solicitud: 'vacaciones',
        remitente_id: user.id,
        remitente_nombre: user.full_name,
        es_admin: false,
        mensaje: mensaje,
        fecha: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mensajes-vacaciones'] });
      setNuevoMensaje("");
    },
  });

  const handleEnviarMensaje = () => {
    if (!nuevoMensaje.trim()) return;
    enviarMensajeMutation.mutate(nuevoMensaje);
  };

  if (!user) {
    return null;
  }

  return (
    <>
      <Card className="shadow-xl border-0">
        <CardHeader className="bg-gradient-to-r from-slate-700 to-slate-800 text-white rounded-t-xl">
          <CardTitle>Mis Solicitudes de Vacaciones</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          {solicitudes.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-slate-600">No has realizado ninguna solicitud de vacaciones</p>
            </div>
          ) : (
            <div className="space-y-4">
              {solicitudes.map((solicitud) => {
                const Icon = estadoIcons[solicitud.estado];
                return (
                  <div key={solicitud.id} className="border-2 border-slate-200 rounded-xl p-5 hover:shadow-lg transition-all duration-200">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Badge className={estadoColors[solicitud.estado]}>
                            <Icon className="w-3 h-3 mr-1" />
                            {solicitud.estado}
                          </Badge>
                          <span className="text-sm text-slate-500">
                            {format(new Date(solicitud.created_date), "dd MMM yyyy", { locale: es })}
                          </span>
                        </div>

                        <div className="mb-2">
                          <p className="font-bold text-lg text-slate-900">
                            {solicitud.dias_solicitados} días laborables
                          </p>
                          <p className="text-sm text-slate-600">
                            <strong>Desde:</strong> {format(parseISO(solicitud.fecha_inicio), "dd MMM yyyy", { locale: es })} - 
                            <strong> Hasta:</strong> {format(parseISO(solicitud.fecha_fin), "dd MMM yyyy", { locale: es })}
                          </p>
                        </div>

                        {solicitud.motivo && (
                          <p className="text-slate-700 bg-slate-50 p-3 rounded-lg mb-2">{solicitud.motivo}</p>
                        )}

                        {solicitud.respuesta_admin && (
                          <div className="mt-3 bg-green-50 p-4 rounded-lg border border-green-200">
                            <p className="text-sm font-semibold text-green-900 mb-2">Respuesta del administrador:</p>
                            <p className="text-green-800">{solicitud.respuesta_admin}</p>
                          </div>
                        )}
                      </div>

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setConversacionAbierta(solicitud)}
                        className="flex items-center gap-2"
                      >
                        <MessageSquare className="w-4 h-4" />
                        Chat
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {conversacionAbierta && (
        <Dialog open={true} onOpenChange={() => setConversacionAbierta(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>
                Conversación - Solicitud de Vacaciones
                <Badge className={`ml-3 ${estadoColors[conversacionAbierta.estado]}`}>
                  {conversacionAbierta.estado}
                </Badge>
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                <p className="font-bold">{conversacionAbierta.dias_solicitados} días laborables</p>
                <p className="text-sm text-slate-600">
                  {format(parseISO(conversacionAbierta.fecha_inicio), "dd MMM yyyy", { locale: es })} - 
                  {format(parseISO(conversacionAbierta.fecha_fin), "dd MMM yyyy", { locale: es })}
                </p>
              </div>

              <div className="max-h-96 overflow-y-auto space-y-3 pr-2">
                {mensajes.map((mensaje) => (
                  <div
                    key={mensaje.id}
                    className={`flex ${mensaje.es_admin ? 'justify-start' : 'justify-end'}`}
                  >
                    <div
                      className={`max-w-[75%] rounded-lg p-4 ${
                        mensaje.es_admin
                          ? 'bg-slate-100 text-slate-900'
                          : 'bg-purple-600 text-white'
                      }`}
                    >
                      <p className="text-sm font-semibold mb-1">{mensaje.remitente_nombre}</p>
                      <p className="text-sm">{mensaje.mensaje}</p>
                      <p className="text-xs mt-2 opacity-70">
                        {format(new Date(mensaje.fecha), "dd MMM HH:mm", { locale: es })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex gap-2 pt-4 border-t">
                <Textarea
                  placeholder="Escribe tu mensaje..."
                  value={nuevoMensaje}
                  onChange={(e) => setNuevoMensaje(e.target.value)}
                  className="flex-1"
                  rows={3}
                />
                <Button
                  onClick={handleEnviarMensaje}
                  disabled={!nuevoMensaje.trim() || enviarMensajeMutation.isPending}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}