import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, startOfWeek, endOfWeek, addMonths, subMonths, isWithinInterval, parseISO } from "date-fns";
import { es } from "date-fns/locale";

export default function CalendarioVacaciones({ solicitudes }) {
  const [mesActual, setMesActual] = useState(new Date());

  const inicioMes = startOfMonth(mesActual);
  const finMes = endOfMonth(mesActual);
  const inicioCalendario = startOfWeek(inicioMes, { locale: es, weekStartsOn: 1 });
  const finCalendario = endOfWeek(finMes, { locale: es, weekStartsOn: 1 });
  
  const diasCalendario = eachDayOfInterval({ start: inicioCalendario, end: finCalendario });

  const esDiaVacaciones = (dia) => {
    return solicitudes.some(solicitud => {
      const inicio = parseISO(solicitud.fecha_inicio);
      const fin = parseISO(solicitud.fecha_fin);
      return isWithinInterval(dia, { start: inicio, end: fin });
    });
  };

  const mesAnterior = () => setMesActual(prev => subMonths(prev, 1));
  const mesSiguiente = () => setMesActual(prev => addMonths(prev, 1));

  return (
    <Card className="shadow-xl border-0">
      <CardHeader className="bg-gradient-to-r from-[#24c4ba] to-[#1ca89f] text-white rounded-t-xl">
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            size="icon"
            onClick={mesAnterior}
            className="text-white hover:bg-white/20"
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <CardTitle className="capitalize text-xl">
            {format(mesActual, 'MMMM yyyy', { locale: es })}
          </CardTitle>
          <Button
            variant="ghost"
            size="icon"
            onClick={mesSiguiente}
            className="text-white hover:bg-white/20"
          >
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-7 gap-2 mb-2">
          {['L', 'M', 'X', 'J', 'V', 'S', 'D'].map(dia => (
            <div key={dia} className="text-center font-semibold text-slate-600 text-sm py-2">
              {dia}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-2">
          {diasCalendario.map((dia) => {
            const esVacacion = esDiaVacaciones(dia);
            const esMesActual = isSameMonth(dia, mesActual);
            
            return (
              <div
                key={dia.toString()}
                className={`
                  aspect-square flex items-center justify-center rounded-lg text-sm font-medium
                  ${!esMesActual ? 'text-slate-300 bg-slate-50' : ''}
                  ${esMesActual && !esVacacion ? 'text-slate-900 bg-white' : ''}
                  ${esVacacion && esMesActual ? 'bg-gradient-to-r from-[#24c4ba] to-[#1ca89f] text-white font-bold ring-2 ring-[#24c4ba] ring-offset-2' : ''}
                `}
              >
                {format(dia, 'd')}
              </div>
            );
          })}
        </div>

        <div className="mt-4 flex items-center gap-2 text-xs">
          <div className="w-4 h-4 bg-gradient-to-r from-[#24c4ba] to-[#1ca89f] rounded"></div>
          <span className="text-slate-600">Días de vacaciones aprobados</span>
        </div>
      </CardContent>
    </Card>
  );
}