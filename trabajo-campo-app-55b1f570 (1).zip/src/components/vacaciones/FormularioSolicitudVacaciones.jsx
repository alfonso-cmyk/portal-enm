import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Calendar, AlertTriangle, Info } from "lucide-react";
import { Calendar as CalendarUI } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format, eachDayOfInterval, isWeekend, parseISO } from "date-fns";
import { es } from "date-fns/locale";

export default function FormularioSolicitudVacaciones({ user, diasDisponibles }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    fecha_inicio: null,
    fecha_fin: null,
    motivo: ""
  });

  const { data: centrosUsuario = [] } = useQuery({
    queryKey: ['centros-usuario', user.id],
    queryFn: async () => {
      const centrosIds = user.centros_asignados || [];
      if (centrosIds.length === 0) return [];
      const centros = await base44.entities.Centro.list();
      return centros.filter(c => centrosIds.includes(c.id));
    },
    initialData: [],
  });

  const { data: festivos = [] } = useQuery({
    queryKey: ['festivos'],
    queryFn: () => base44.entities.Festivo.list(),
    initialData: [],
  });

  const ubicacionFestivos = centrosUsuario.length > 1 ? 'Madrid' : 
    (centrosUsuario[0]?.direccion?.includes('Madrid') ? 'Madrid' : 
     centrosUsuario[0]?.direccion?.includes('Barcelona') ? 'Barcelona' : 'Madrid');

  const festivosAplicables = festivos.filter(f => 
    f.tipo === 'nacional' || 
    (f.tipo === 'comunidad' && f.ubicacion === ubicacionFestivos) ||
    (f.tipo === 'local' && f.ubicacion === ubicacionFestivos)
  );

  const esFestivo = (fecha) => {
    const fechaStr = format(fecha, 'yyyy-MM-dd');
    return festivosAplicables.some(f => f.fecha === fechaStr);
  };

  const calcularDiasLaborables = (inicio, fin) => {
    if (!inicio || !fin) return 0;
    
    const dias = eachDayOfInterval({ start: inicio, end: fin });
    let diasLaborables = 0;

    dias.forEach(dia => {
      if (!isWeekend(dia) && !esFestivo(dia)) {
        diasLaborables++;
      }
    });

    return diasLaborables;
  };

  const diasSolicitados = formData.fecha_inicio && formData.fecha_fin
    ? calcularDiasLaborables(formData.fecha_inicio, formData.fecha_fin)
    : 0;

  const createSolicitudMutation = useMutation({
    mutationFn: async (data) => {
      if (diasSolicitados > diasDisponibles) {
        throw new Error(`No tienes suficientes días disponibles. Tienes ${diasDisponibles} días y estás solicitando ${diasSolicitados} días laborables.`);
      }

      console.log('🚀 Creando solicitud de vacaciones...');

      // 1. Crear la solicitud de vacaciones
      const solicitud = await base44.entities.SolicitudVacaciones.create({
        empleado_id: user.id,
        empleado_nombre: user.full_name,
        fecha_inicio: format(data.fecha_inicio, 'yyyy-MM-dd'),
        fecha_fin: format(data.fecha_fin, 'yyyy-MM-dd'),
        dias_solicitados: diasSolicitados,
        motivo: data.motivo,
        estado: 'pendiente'
      });

      console.log('✅ Solicitud de vacaciones creada:', solicitud.id);

      // 2. Crear mensaje inicial en el chat
      await base44.entities.MensajeSolicitud.create({
        solicitud_id: solicitud.id,
        tipo_solicitud: 'vacaciones',
        remitente_id: user.id,
        remitente_nombre: user.full_name,
        es_admin: false,
        mensaje: `Solicitud de vacaciones: ${diasSolicitados} días laborables desde ${format(data.fecha_inicio, 'dd/MM/yyyy')} hasta ${format(data.fecha_fin, 'dd/MM/yyyy')}. ${data.motivo ? 'Motivo: ' + data.motivo : ''}`,
        fecha: new Date().toISOString()
      });

      console.log('✅ Mensaje inicial creado');

      // 3. ✅ SOLO NOTIFICACIÓN CAMPANITA - NO EMAIL
      const notificacion = await base44.entities.Solicitud.create({
        empleado_id: user.id,
        empleado_nombre: user.full_name,
        tipo_solicitud: 'vacaciones',
        asunto: `Solicitud de Vacaciones - ${diasSolicitados} días`,
        descripcion: `${user.full_name} ha solicitado ${diasSolicitados} días de vacaciones desde el ${format(data.fecha_inicio, 'dd/MM/yyyy')} hasta el ${format(data.fecha_fin, 'dd/MM/yyyy')}.\n\nMotivo: ${data.motivo || 'No especificado'}`,
        estado: 'pendiente',
        respuesta: null,
        fecha_respuesta: null
      });

      console.log('✅ Notificación campanita creada:', notificacion.id);

      // ⛔ NO ENVIAR EMAIL
      // ⛔ NO LLAMAR A SendEmail

      return solicitud;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vacaciones'] });
      queryClient.invalidateQueries({ queryKey: ['solicitudes-pendientes'] });
      queryClient.invalidateQueries({ queryKey: ['vacaciones-pendientes'] });
      setFormData({ fecha_inicio: null, fecha_fin: null, motivo: "" });
      alert('✅ Solicitud de vacaciones enviada correctamente');
    },
    onError: (error) => {
      console.error('❌ Error:', error);
      alert('❌ Error: ' + error.message);
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.fecha_inicio || !formData.fecha_fin) {
      alert('Por favor, selecciona las fechas de inicio y fin');
      return;
    }
    if (formData.fecha_fin < formData.fecha_inicio) {
      alert('La fecha de fin no puede ser anterior a la fecha de inicio');
      return;
    }
    createSolicitudMutation.mutate(formData);
  };

  const disabledDays = (date) => {
    return isWeekend(date) || esFestivo(date);
  };

  return (
    <Card className="shadow-xl border-0">
      <CardHeader className="bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-t-xl">
        <CardTitle className="flex items-center gap-2">
          <Calendar className="w-6 h-6" />
          Solicitar Vacaciones
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <Alert className="mb-6 border-purple-200 bg-purple-50">
          <Info className="h-4 w-4 text-purple-600" />
          <AlertDescription className="text-purple-900">
            <strong>Días disponibles:</strong> {diasDisponibles} días laborables
            <br />
            <strong>Ubicación festivos:</strong> {ubicacionFestivos}
            <br />
            <span className="text-xs">Los fines de semana y festivos no cuentan como días de vacaciones</span>
          </AlertDescription>
        </Alert>

        {festivosAplicables.length > 0 && (
          <Alert className="mb-6 border-blue-200 bg-blue-50">
            <Calendar className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-900">
              <strong>Festivos próximos ({festivosAplicables.length}):</strong>
              <div className="mt-2 max-h-32 overflow-y-auto text-xs space-y-1">
                {festivosAplicables
                  .filter(f => new Date(f.fecha) >= new Date())
                  .slice(0, 10)
                  .map(f => (
                    <div key={f.id}>
                      • {f.nombre} - {format(parseISO(f.fecha), 'dd/MM/yyyy')} ({f.tipo})
                    </div>
                  ))}
              </div>
            </AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <Label>Fecha de Inicio *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left mt-2">
                    <Calendar className="mr-2 h-4 w-4" />
                    {formData.fecha_inicio ? format(formData.fecha_inicio, 'dd/MM/yyyy') : 'Seleccionar'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <CalendarUI
                    mode="single"
                    selected={formData.fecha_inicio}
                    onSelect={(date) => setFormData({...formData, fecha_inicio: date})}
                    disabled={disabledDays}
                    locale={es}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <Label>Fecha de Fin *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left mt-2">
                    <Calendar className="mr-2 h-4 w-4" />
                    {formData.fecha_fin ? format(formData.fecha_fin, 'dd/MM/yyyy') : 'Seleccionar'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <CalendarUI
                    mode="single"
                    selected={formData.fecha_fin}
                    onSelect={(date) => setFormData({...formData, fecha_fin: date})}
                    disabled={disabledDays}
                    locale={es}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {diasSolicitados > 0 && (
            <Alert className={diasSolicitados > diasDisponibles ? "border-red-200 bg-red-50" : "border-green-200 bg-green-50"}>
              <AlertTriangle className={`h-4 w-4 ${diasSolicitados > diasDisponibles ? 'text-red-600' : 'text-green-600'}`} />
              <AlertDescription className={diasSolicitados > diasDisponibles ? 'text-red-900' : 'text-green-900'}>
                <strong>Días laborables solicitados: {diasSolicitados}</strong>
                {diasSolicitados > diasDisponibles && (
                  <div className="mt-1 text-sm">
                    ⚠️ No tienes suficientes días disponibles ({diasDisponibles} disponibles)
                  </div>
                )}
              </AlertDescription>
            </Alert>
          )}

          <div>
            <Label>Motivo (Opcional)</Label>
            <Textarea
              value={formData.motivo}
              onChange={(e) => setFormData({...formData, motivo: e.target.value})}
              placeholder="Escribe el motivo de tu solicitud..."
              className="mt-2 h-24"
            />
          </div>

          <Button
            type="submit"
            disabled={createSolicitudMutation.isPending || diasSolicitados === 0 || diasSolicitados > diasDisponibles}
            className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 py-6 text-lg"
          >
            {createSolicitudMutation.isPending ? 'Enviando...' : 'Enviar Solicitud'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}