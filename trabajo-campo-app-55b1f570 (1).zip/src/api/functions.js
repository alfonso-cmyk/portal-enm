import { base44 } from './base44Client';


export const verificarFichajes = base44.functions.verificarFichajes;

export const calcularImpuestosAutomaticos = base44.functions.calcularImpuestosAutomaticos;

